﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERPSC.Models
{
    public class Movimentacao
    {
        public int idMovimentacao{get; set;}
        public String descricao {get; set;}
        public Produto produto { get; set; }
        public DateTime data { get; set; }
        public int quantidade { get; set; }
        public Deposito deposito { get; set; }
   
    }
}