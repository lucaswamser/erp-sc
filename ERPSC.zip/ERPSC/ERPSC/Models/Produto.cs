﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERPSC.Models
{
    public class Produto
    {
        public int idProduto { get; set;}
        public String nome{get; set;}
        public Double preco { get; set; }
        public Double peso { get; set; }

    }
}