﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERPSC.Models
{
    public class Deposito
    {
        public int idDeposito { get; set; }
        public String nome { get; set; }

    }
}