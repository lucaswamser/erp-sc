﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERPSC.Models
{
    public class MovimentacaoSaida : Movimentacao
    {
    }
}