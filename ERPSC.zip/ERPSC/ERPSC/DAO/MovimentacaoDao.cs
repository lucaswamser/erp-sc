﻿using ERPSC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ERPSC.DAO
{
    public class MovimentacaoDao
    {
        private SqlConnection connection;
        public MovimentacaoDao()
        {
            this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DB1"].ToString());
            this.connection.Open();
        }

        public List<Movimentacao> listar()
        {
            SqlCommand cm = new SqlCommand("SELECT idMovimentacao,data,tipo,descricao,quantidade,produto,idProduto FROM visualizarMovimentacoes", connection);
            SqlDataReader reader = cm.ExecuteReader();
            List<Movimentacao> movimentacoes = new List<Movimentacao>();
            while (reader.Read())
            {

                Movimentacao movimentacao;
                if (reader.GetString(2) == "S")
                    movimentacao = new MovimentacaoSaida();
                else
                    movimentacao = new MovimentacaoEntrada();

                movimentacao.idMovimentacao = reader.GetInt32(0);
                movimentacao.data = reader.GetDateTime(1);
                movimentacao.descricao = reader.GetString(3);
                movimentacao.quantidade = reader.GetInt32(4);
                movimentacao.produto = new Produto { nome = reader.GetString(5), idProduto = reader.GetInt32(6) };
                movimentacoes.Add(movimentacao);
            }
            return movimentacoes;
        }


    }
}