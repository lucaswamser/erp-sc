﻿using ERPSC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ERPSC.DAO
{
    public class DepositoDao
    {
        private SqlConnection connection;
        public DepositoDao()
        {
          this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DB1"].ToString());
            this.connection.Open();
        }


        public void adicionar(Deposito deposito)
        {
            SqlCommand cm = new SqlCommand("adicionarDeposito",connection);
            cm.CommandType = System.Data.CommandType.StoredProcedure;
            cm.Parameters.Add("Nome", SqlDbType.VarChar).Value = deposito.nome;
            cm.ExecuteReader();
        }

        public List<Deposito> listar()
        {
            SqlCommand cm = new SqlCommand("SELECT idDeposito,nome FROM visualizarDepositos",connection);
            SqlDataReader reader = cm.ExecuteReader();
            List<Deposito> depositos = new List<Deposito>();
            while (reader.Read())
            {
                Deposito deposito = new Deposito();
                deposito.idDeposito = reader.GetInt32(0);
                deposito.nome = reader.GetString(1);
                depositos.Add(deposito);
            }
            return depositos;
        }

    }
}