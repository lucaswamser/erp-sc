﻿using ERPSC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ERPSC.DAO
{
    public class ProdutoDao
    {
        private SqlConnection connection;
        public ProdutoDao()
        {
          this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DB1"].ToString());
            this.connection.Open();
        }


        public void adicionar(Produto produto)
        {
            SqlCommand cm = new SqlCommand("adicionarProduto",connection);
            cm.CommandType = System.Data.CommandType.StoredProcedure;
            cm.Parameters.Add("Nome", SqlDbType.VarChar).Value = produto.nome;
            cm.Parameters.Add("Peso", SqlDbType.Float).Value = produto.peso;
            cm.Parameters.Add("Preco", SqlDbType.Float).Value = produto.preco;
            cm.ExecuteReader();
        }

        public List<Produto> listar()
        {
            SqlCommand cm = new SqlCommand("SELECT idProduto,nome,peso,preco FROM visualizarProdutos",connection);
            SqlDataReader reader = cm.ExecuteReader();
            List<Produto> produtos = new List<Produto>();
            while (reader.Read())
            {
                Produto produto = new Produto();
                produto.idProduto = reader.GetInt32(0);
                produto.nome = reader.GetString(1);
                produto.preco = reader.GetDouble(2);
                produto.peso = reader.GetDouble(3);
                produtos.Add(produto);
            }
            return produtos;
        }

    }
}