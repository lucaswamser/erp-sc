﻿using ERPSC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ERPSC.DAO
{
    public class ProdutoDepositoDao
    {
        private SqlConnection connection;
        public ProdutoDepositoDao()
        {
          this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DB1"].ToString());
            this.connection.Open();
        }

        public List<ProdutoDeposito> listar()
        {
            SqlCommand cm = new SqlCommand("SELECT idProduto,nome,peso,preco,quantidade FROM visualizarInventario WHERE quantidade is not null", connection);
            SqlDataReader reader = cm.ExecuteReader();
            List<ProdutoDeposito> produtos = new List<ProdutoDeposito>();
            while (reader.Read())
            {
                ProdutoDeposito produto = new ProdutoDeposito();
                produto.idProduto = reader.GetInt32(0);
                produto.nome = reader.GetString(1);
                produto.preco = reader.GetDouble(2);
                produto.peso = reader.GetDouble(3);
                produto.quantidade = reader.GetInt32(4);
                produtos.Add(produto);
            }
            return produtos;
        }

    }
}