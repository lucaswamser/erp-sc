﻿using ERPSC.DAO;
using ERPSC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ERPSC.Controllers
{
    public class MovimentoController : Controller
    {
        private MovimentacaoDao dao;

        public MovimentoController()
        {
            dao = new MovimentacaoDao();
        }


        // GET: MovimentoSaida
        public ActionResult Index()
        {
            return View(dao.listar());
        }

        public ActionResult Entrada()
        {
            return View();
        }

        // POST: MovimentoSaida/Create
        [HttpPost]
        public ActionResult Entrada(MovimentacaoEntrada movimentacao)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Saida()
        {
            return View();
        }

        // POST: MovimentoSaida/Create
        [HttpPost]
        public ActionResult Saida(MovimentacaoSaida movimentacao)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    }
}
