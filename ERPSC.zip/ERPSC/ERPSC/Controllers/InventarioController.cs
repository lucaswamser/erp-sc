﻿using ERPSC.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ERPSC.Controllers
{
    public class InventarioController : Controller
    {
        private ProdutoDepositoDao dao;

        public InventarioController()
        {
            dao = new ProdutoDepositoDao();
        }

        // GET: Inventario
        public ActionResult Index()
        {
            return View(dao.listar());
        }
    }
}